package hk.javaprojects.springbootkafkaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootKafkaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootKafkaProjectApplication.class, args);
	}

}
