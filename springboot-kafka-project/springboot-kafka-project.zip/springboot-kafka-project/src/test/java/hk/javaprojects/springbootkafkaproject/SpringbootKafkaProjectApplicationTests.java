package hk.javaprojects.springbootkafkaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
